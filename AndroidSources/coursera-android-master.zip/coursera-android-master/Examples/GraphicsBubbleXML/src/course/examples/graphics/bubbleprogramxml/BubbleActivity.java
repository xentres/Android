package course.examples.graphics.bubbleprogramxml;

import android.app.Activity;
import android.os.Bundle;

public class BubbleActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
}